



   //         $result = mysqli_query($conn,"SELECT * FROM users WHERE username = '$Username'");
    //         if ($result) {
    //             while($row=mysqli_fetch_assoc($result)){                  
    //                 $output[]=$row;
    //             }
    //             echo json_encode($output);
    //         }
    //     } else echo "Wellcome";
    // }




    //         $query = "SELECT * FROM info_users WHERE username = '$Username'";
    //         $result = mysqli_query($conn, $query);
    //         $num = mysqli_num_rows($result);
    //         if ($num == 1){
    //             while ($row = mysqli_fetch_assoc($result)){
    //                 if (password_verify($Password,$row['password'])) {		
    //                     $output[] = $row;				
    //                 }
    //                 else{
    //                     echo "error";
    //                 }	
    //             }			
    //             echo json_encode($output);
    //         }else echo "Wellcome";
    //     }
    // }